package hangman;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Congrats extends JFrame{
	
	public Congrats() {
		setTitle("hangman");
		setSize(500,200);
		setLayout(new FlowLayout());
		
		JButton congrats = new JButton("CONGRATULATIONS! YOU WON!");
		congrats.setPreferredSize(new Dimension(350,120));
		
		class Exit implements ActionListener{
			public void actionPerformed(ActionEvent e) {
				//EXIT��ư Ŭ�� �� ����â ����
				System.exit(0);
			}
		}
		//��ư Ŭ�� �� ���� ����
		congrats.addActionListener(new Exit());
		
		add(congrats);
		setVisible(true);
	}
	

	public static void main(String[] args) {
		new Congrats();
	}
}
