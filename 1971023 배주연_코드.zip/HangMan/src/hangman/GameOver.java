package hangman;

import java.awt.*;
import java.awt.event.*;
import java.io.FileNotFoundException;

import javax.swing.*;

public class GameOver extends JFrame{
	
	public GameOver() {
		setTitle("hangman");
		setSize(500,200);
		setLayout(new FlowLayout());
		
		JButton gameover = new JButton("you lost! try again next time! --answer is saved in file--");
		gameover.setPreferredSize(new Dimension(350,120));
		
		
		class Exit implements ActionListener{
			public void actionPerformed(ActionEvent e) {
				//EXIT��ư Ŭ�� �� ����â ����
				System.exit(0);
			}
		}
		//��ư Ŭ�� �� ���� ����
		gameover.addActionListener(new Exit());
		
		add(gameover);
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		new GameOver();
	}
}
